
Illustrates the use of Dialog free operation. You would find this useful
if you are building a proxy server ( where you dont want to keep dialog
support).

Note that the Dialog pointer extracted from the ServerTransaction is null.



